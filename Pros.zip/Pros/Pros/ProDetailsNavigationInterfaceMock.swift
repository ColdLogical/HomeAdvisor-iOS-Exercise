@testable import Pros

class ProDetailsNavigationInterfaceMock {
        var functionsCalled = [String]()

        // MARK: - Input Variables
}

extension ProDetailsNavigationInterfaceMock: ProDetailsNavigationInterface {

}
