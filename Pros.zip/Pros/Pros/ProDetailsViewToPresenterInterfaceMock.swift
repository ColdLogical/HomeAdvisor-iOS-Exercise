@testable import Pros

class ProDetailsViewToPresenterInterfaceMock {
        var functionsCalled = [String]()

        // MARK: - Input Variables
}

extension ProDetailsViewToPresenterInterfaceMock: ProDetailsViewToPresenterInterface {

}
