// VIPER Interface for communication from Presenter to Interactor
protocol ProDetailsPresenterToInteractorInterface: class {

}
