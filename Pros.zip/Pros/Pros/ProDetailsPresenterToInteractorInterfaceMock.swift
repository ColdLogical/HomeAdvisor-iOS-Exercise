@testable import Pros

class ProDetailsPresenterToInteractorInterfaceMock {
        var functionsCalled = [String]()

        // MARK: - Input Variables
}

extension ProDetailsPresenterToInteractorInterfaceMock: ProDetailsPresenterToInteractorInterface {

}
