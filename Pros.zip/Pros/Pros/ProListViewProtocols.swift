// VIPER Interface for manipulating the navigation of the view
protocol ProListNavigationInterface: class {

}

// VIPER Interface for communication from Presenter -> View
protocol ProListPresenterToViewInterface: class {
        func show(proListViewObjects: [ProListViewObject])
}
