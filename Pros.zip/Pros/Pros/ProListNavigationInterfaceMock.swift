@testable import Pros

class ProListNavigationInterfaceMock {
        var functionsCalled = [String]()

        // MARK: - Input Variables
}

extension ProListNavigationInterfaceMock: ProListNavigationInterface {

}
