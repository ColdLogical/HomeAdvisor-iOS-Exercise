// VIPER Interface for communication from Presenter to Interactor
protocol ProListPresenterToInteractorInterface: class {
        func getPros()
}
