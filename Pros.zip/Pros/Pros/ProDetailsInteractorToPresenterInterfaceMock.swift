@testable import Pros

class ProDetailsInteractorToPresenterInterfaceMock {
        var functionsCalled = [String]()

        // MARK: - Input Variables
}

extension ProDetailsInteractorToPresenterInterfaceMock: ProDetailsInteractorToPresenterInterface {

}
