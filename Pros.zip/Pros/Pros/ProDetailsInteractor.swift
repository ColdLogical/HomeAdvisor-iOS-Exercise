import Foundation

class ProDetailsInteractor {
        // MARK: - VIPER Stack
        weak var presenter: ProDetailsInteractorToPresenterInterface!

        // MARK: - Instance Variables

        // MARK: - Operational

}

// MARK: - Presenter To Interactor Interface
extension ProDetailsInteractor: ProDetailsPresenterToInteractorInterface {

}
